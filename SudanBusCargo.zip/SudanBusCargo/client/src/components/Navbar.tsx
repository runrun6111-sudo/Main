import { Link, useLocation } from "wouter";
import { Bus, Package, HelpCircle, LayoutDashboard, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { path: "/", label: "الرئيسية", icon: null },
    { path: "/tickets", label: "حجز التذاكر", icon: Bus },
    { path: "/cargo", label: "الشحن", icon: Package },
    { path: "/support", label: "الدعم الفني", icon: HelpCircle },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo - Right side for RTL */}
          <Link href="/">
            <div className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-lg px-3 py-2 -mr-3 cursor-pointer" data-testid="link-home">
              <Bus className="h-8 w-8 text-primary" />
              <span className="font-bold text-lg hidden md:inline">رِحّال</span>
            </div>
          </Link>

          {/* Desktop Navigation - Center */}
          <div className="hidden md:flex items-center gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = location === link.path;
              return (
                <Button
                  key={link.path}
                  variant={isActive ? "secondary" : "ghost"}
                  className="gap-2"
                  data-testid={`link-nav-${link.label}`}
                  asChild
                >
                  <Link href={link.path}>
                    {Icon && <Icon className="h-4 w-4" />}
                    <span>{link.label}</span>
                  </Link>
                </Button>
              );
            })}
          </div>

          {/* Admin Link & Mobile Menu - Left side for RTL */}
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2 hidden md:flex" data-testid="link-admin" asChild>
              <Link href="/admin">
                <LayoutDashboard className="h-4 w-4" />
                <span>لوحة التحكم</span>
              </Link>
            </Button>

            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex flex-col gap-4 mt-8">
                  {navLinks.map((link) => {
                    const Icon = link.icon;
                    const isActive = location === link.path;
                    return (
                      <Button
                        key={link.path}
                        onClick={() => setMobileMenuOpen(false)}
                        variant={isActive ? "secondary" : "ghost"}
                        className="w-full justify-start gap-3"
                        data-testid={`link-mobile-${link.label}`}
                        asChild
                      >
                        <Link href={link.path}>
                          {Icon && <Icon className="h-5 w-5" />}
                          <span className="text-base">{link.label}</span>
                        </Link>
                      </Button>
                    );
                  })}
                  <Button 
                    onClick={() => setMobileMenuOpen(false)}
                    variant="outline" 
                    className="w-full justify-start gap-3" 
                    data-testid="link-mobile-admin"
                    asChild
                  >
                    <Link href="/admin">
                      <LayoutDashboard className="h-5 w-5" />
                      <span className="text-base">لوحة التحكم</span>
                    </Link>
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
