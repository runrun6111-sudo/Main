import { Bus, Mail, Phone, MapPin } from "lucide-react";
import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-card border-t border-card-border mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Bus className="h-6 w-6 text-primary" />
              <h3 className="font-bold text-lg">رِحّال</h3>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              منصتك الموثوقة لحجز تذاكر الباصات والشحن عبر ولايات السودان. نربطك بأفضل الوكالات لرحلة آمنة ومريحة.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/tickets" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
                  حجز التذاكر
                </Link>
              </li>
              <li>
                <Link href="/cargo" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
                  خدمات الشحن
                </Link>
              </li>
              <li>
                <Link href="/support" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
                  الدعم الفني
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">تواصل معنا</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-muted-foreground text-sm">
                <Phone className="h-4 w-4 text-primary" />
                <span>+249 123 456 789</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground text-sm">
                <Mail className="h-4 w-4 text-primary" />
                <span>info@rehlaamna.sd</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground text-sm">
                <MapPin className="h-4 w-4 text-primary" />
                <span>الخرطوم، السودان</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-6 text-center">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} رِحّال. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
}
