import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { LayoutDashboard, Building2, Ticket as TicketIcon, Package as PackageIcon, MessageSquare, Plus, Edit, Trash2, Bus } from "lucide-react";
import { insertAgencySchema, insertTicketSchema, sudaneseCities, type Agency, type Ticket, type TravelBooking, type CargoShipment, type SupportMessage, type InsertAgency, type InsertTicket } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

export default function Admin() {
  const [activeTab, setActiveTab] = useState("overview");
  const [agencyDialogOpen, setAgencyDialogOpen] = useState(false);
  const [ticketDialogOpen, setTicketDialogOpen] = useState(false);
  const { toast } = useToast();

  // Fetch data
  const { data: agencies } = useQuery<Agency[]>({ queryKey: ["/api/agencies"] });
  const { data: tickets } = useQuery<(Ticket & { agency: Agency })[]>({ queryKey: ["/api/tickets/all"] });
  const { data: bookings } = useQuery<(TravelBooking & { ticket: Ticket & { agency: Agency } })[]>({ 
    queryKey: ["/api/bookings"] 
  });
  const { data: cargo } = useQuery<CargoShipment[]>({ queryKey: ["/api/cargo"] });
  const { data: support } = useQuery<SupportMessage[]>({ queryKey: ["/api/support"] });

  // Forms
  const agencyForm = useForm<InsertAgency>({
    resolver: zodResolver(insertAgencySchema),
    defaultValues: {
      name: "",
      logo: "",
      rating: "4.5",
      phone: "",
      email: "",
    },
  });

  const ticketForm = useForm<InsertTicket>({
    resolver: zodResolver(insertTicketSchema),
    defaultValues: {
      agencyId: "",
      fromCity: "",
      toCity: "",
      departureTime: "",
      price: "0",
      availableSeats: 50,
      busType: "عادي",
      duration: "",
    },
  });

  // Mutations
  const createAgency = useMutation({
    mutationFn: (data: InsertAgency) => apiRequest("POST", "/api/agencies", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/agencies"] });
      toast({ title: "تمت الإضافة!", description: "تم إضافة الوكالة بنجاح" });
      setAgencyDialogOpen(false);
      agencyForm.reset();
    },
  });

  const createTicket = useMutation({
    mutationFn: (data: InsertTicket) => apiRequest("POST", "/api/tickets", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets/all"] });
      toast({ title: "تمت الإضافة!", description: "تم إضافة التذكرة بنجاح" });
      setTicketDialogOpen(false);
      ticketForm.reset();
    },
  });

  const deleteTicket = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/tickets/${id}`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets/all"] });
      toast({ title: "تم الحذف!", description: "تم حذف التذكرة بنجاح" });
    },
  });

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-primary/10 p-3 rounded-lg">
              <LayoutDashboard className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold" data-testid="text-page-title">لوحة التحكم الإدارية</h1>
          </div>
          <p className="text-muted-foreground">إدارة الوكالات، التذاكر، والحجوزات</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 h-auto gap-2">
            <TabsTrigger value="overview" className="gap-2" data-testid="tab-overview">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">نظرة عامة</span>
            </TabsTrigger>
            <TabsTrigger value="agencies" className="gap-2" data-testid="tab-agencies">
              <Building2 className="h-4 w-4" />
              <span className="hidden sm:inline">الوكالات</span>
            </TabsTrigger>
            <TabsTrigger value="tickets" className="gap-2" data-testid="tab-tickets">
              <TicketIcon className="h-4 w-4" />
              <span className="hidden sm:inline">التذاكر</span>
            </TabsTrigger>
            <TabsTrigger value="cargo" className="gap-2" data-testid="tab-cargo">
              <PackageIcon className="h-4 w-4" />
              <span className="hidden sm:inline">الشحن</span>
            </TabsTrigger>
            <TabsTrigger value="support" className="gap-2" data-testid="tab-support">
              <MessageSquare className="h-4 w-4" />
              <span className="hidden sm:inline">الدعم</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الوكالات</CardTitle>
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{agencies?.length || 0}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">التذاكر المتاحة</CardTitle>
                  <TicketIcon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{tickets?.length || 0}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الحجوزات</CardTitle>
                  <Bus className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{bookings?.length || 0}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">طلبات الشحن</CardTitle>
                  <PackageIcon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{cargo?.length || 0}</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Bookings */}
            <Card>
              <CardHeader>
                <CardTitle>آخر الحجوزات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {bookings?.slice(0, 5).map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <div>
                        <p className="font-medium">{booking.passengerName}</p>
                        <p className="text-sm text-muted-foreground">
                          {booking.ticket.fromCity} ← {booking.ticket.toCity}
                        </p>
                      </div>
                      <Badge variant={booking.status === "confirmed" ? "default" : "secondary"}>
                        {booking.status}
                      </Badge>
                    </div>
                  )) || <p className="text-muted-foreground text-center py-8">لا توجد حجوزات بعد</p>}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Agencies Tab */}
          <TabsContent value="agencies" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة الوكالات</h2>
              <Button onClick={() => setAgencyDialogOpen(true)} className="gap-2" data-testid="button-add-agency">
                <Plus className="h-4 w-4" />
                إضافة وكالة
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>اسم الوكالة</TableHead>
                      <TableHead>التقييم</TableHead>
                      <TableHead>الهاتف</TableHead>
                      <TableHead>البريد الإلكتروني</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {agencies?.map((agency) => (
                      <TableRow key={agency.id}>
                        <TableCell className="font-medium">{agency.name}</TableCell>
                        <TableCell>{agency.rating}</TableCell>
                        <TableCell>{agency.phone}</TableCell>
                        <TableCell>{agency.email}</TableCell>
                      </TableRow>
                    )) || (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          لا توجد وكالات بعد
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tickets Tab */}
          <TabsContent value="tickets" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">إدارة التذاكر</h2>
              <Button onClick={() => setTicketDialogOpen(true)} className="gap-2" data-testid="button-add-ticket">
                <Plus className="h-4 w-4" />
                إضافة تذكرة
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>الوكالة</TableHead>
                      <TableHead>المسار</TableHead>
                      <TableHead>الوقت</TableHead>
                      <TableHead>السعر</TableHead>
                      <TableHead>المقاعد</TableHead>
                      <TableHead>النوع</TableHead>
                      <TableHead>إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tickets?.map((ticket) => (
                      <TableRow key={ticket.id}>
                        <TableCell>{ticket.agency.name}</TableCell>
                        <TableCell>{ticket.fromCity} ← {ticket.toCity}</TableCell>
                        <TableCell>{ticket.departureTime}</TableCell>
                        <TableCell>{ticket.price} ج.س</TableCell>
                        <TableCell>{ticket.availableSeats}</TableCell>
                        <TableCell>
                          <Badge variant={ticket.busType === "VIP" ? "default" : "secondary"}>
                            {ticket.busType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteTicket.mutate(ticket.id)}
                            data-testid={`button-delete-${ticket.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    )) || (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                          لا توجد تذاكر بعد
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cargo Tab */}
          <TabsContent value="cargo" className="space-y-4">
            <h2 className="text-2xl font-bold">طلبات الشحن</h2>
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>المرسل</TableHead>
                      <TableHead>المستلم</TableHead>
                      <TableHead>المسار</TableHead>
                      <TableHead>الوزن</TableHead>
                      <TableHead>السعر</TableHead>
                      <TableHead>الحالة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cargo?.map((shipment) => (
                      <TableRow key={shipment.id}>
                        <TableCell>{shipment.senderName}</TableCell>
                        <TableCell>{shipment.receiverName}</TableCell>
                        <TableCell>{shipment.fromCity} ← {shipment.toCity}</TableCell>
                        <TableCell>{shipment.weight} كجم</TableCell>
                        <TableCell>{shipment.estimatedPrice} ج.س</TableCell>
                        <TableCell>
                          <Badge>{shipment.status}</Badge>
                        </TableCell>
                      </TableRow>
                    )) || (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          لا توجد طلبات شحن بعد
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Support Tab */}
          <TabsContent value="support" className="space-y-4">
            <h2 className="text-2xl font-bold">رسائل الدعم الفني</h2>
            <div className="grid gap-4">
              {support?.map((message) => (
                <Card key={message.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{message.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{message.email} • {message.phone}</p>
                      </div>
                      <Badge>{message.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{message.message}</p>
                  </CardContent>
                </Card>
              )) || (
                <Card>
                  <CardContent className="p-12 text-center">
                    <p className="text-muted-foreground">لا توجد رسائل دعم بعد</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Add Agency Dialog */}
      <Dialog open={agencyDialogOpen} onOpenChange={setAgencyDialogOpen}>
        <DialogContent data-testid="dialog-add-agency">
          <DialogHeader>
            <DialogTitle>إضافة وكالة جديدة</DialogTitle>
          </DialogHeader>
          <Form {...agencyForm}>
            <form onSubmit={agencyForm.handleSubmit((data) => createAgency.mutate(data))} className="space-y-4">
              <FormField
                control={agencyForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>اسم الوكالة</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-agency-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={agencyForm.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم الهاتف</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-agency-phone" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={agencyForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>البريد الإلكتروني</FormLabel>
                    <FormControl>
                      <Input type="email" {...field} data-testid="input-agency-email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit" data-testid="button-submit-agency">
                  إضافة
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Add Ticket Dialog */}
      <Dialog open={ticketDialogOpen} onOpenChange={setTicketDialogOpen}>
        <DialogContent className="max-w-2xl" data-testid="dialog-add-ticket">
          <DialogHeader>
            <DialogTitle>إضافة تذكرة جديدة</DialogTitle>
          </DialogHeader>
          <Form {...ticketForm}>
            <form onSubmit={ticketForm.handleSubmit((data) => createTicket.mutate(data))} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={ticketForm.control}
                  name="agencyId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الوكالة</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-agency">
                            <SelectValue placeholder="اختر الوكالة" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {agencies?.map((agency) => (
                            <SelectItem key={agency.id} value={agency.id}>{agency.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={ticketForm.control}
                  name="fromCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>من</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-from">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sudaneseCities.map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={ticketForm.control}
                  name="toCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>إلى</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-to">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sudaneseCities.map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={ticketForm.control}
                  name="departureTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>وقت المغادرة</FormLabel>
                      <FormControl>
                        <Input placeholder="08:00" {...field} data-testid="input-ticket-time" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={ticketForm.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>السعر (ج.س)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} data-testid="input-ticket-price" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={ticketForm.control}
                  name="availableSeats"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المقاعد المتاحة</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} onChange={e => field.onChange(parseInt(e.target.value))} data-testid="input-ticket-seats" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={ticketForm.control}
                  name="busType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع الباص</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="عادي">عادي</SelectItem>
                          <SelectItem value="VIP">VIP</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={ticketForm.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المدة</FormLabel>
                      <FormControl>
                        <Input placeholder="3 ساعات" {...field} data-testid="input-ticket-duration" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button type="submit" data-testid="button-submit-ticket">
                  إضافة التذكرة
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
