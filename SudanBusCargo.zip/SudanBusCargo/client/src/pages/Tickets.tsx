import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { CalendarIcon, Search, Bus, Clock, MapPin, Users, Star } from "lucide-react";
import { sudaneseCities, insertTravelBookingSchema, type Ticket, type Agency, type InsertTravelBooking } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Tickets() {
  const [fromCity, setFromCity] = useState("");
  const [toCity, setToCity] = useState("");
  const [date, setDate] = useState<Date>();
  const [passengers, setPassengers] = useState("1");
  const [selectedTicket, setSelectedTicket] = useState<(Ticket & { agency: Agency }) | null>(null);
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);
  const { toast } = useToast();

  // Fetch tickets
  const { data: tickets, isLoading } = useQuery<(Ticket & { agency: Agency })[]>({
    queryKey: ["/api/tickets", { fromCity, toCity }],
    enabled: !!(fromCity && toCity),
  });

  const form = useForm<InsertTravelBooking>({
    resolver: zodResolver(insertTravelBookingSchema),
    defaultValues: {
      ticketId: "",
      passengerName: "",
      passengerPhone: "",
      passengerEmail: "",
      numberOfPassengers: 1,
      travelDate: "",
      totalPrice: "0",
      status: "pending",
    },
  });

  const bookingMutation = useMutation({
    mutationFn: (data: InsertTravelBooking) => apiRequest("POST", "/api/bookings", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      toast({
        title: "تم الحجز بنجاح!",
        description: "سيتم التواصل معك قريباً لتأكيد الحجز.",
      });
      setBookingDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "خطأ في الحجز",
        description: "حدث خطأ أثناء الحجز. الرجاء المحاولة مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  const handleBooking = (ticket: Ticket & { agency: Agency }) => {
    setSelectedTicket(ticket);
    const numPassengers = parseInt(passengers) || 1;
    const totalPrice = (parseFloat(ticket.price) * numPassengers).toFixed(2);
    
    form.reset({
      ticketId: ticket.id,
      passengerName: "",
      passengerPhone: "",
      passengerEmail: "",
      numberOfPassengers: numPassengers,
      travelDate: date ? format(date, "yyyy-MM-dd") : "",
      totalPrice,
      status: "pending",
    });
    setBookingDialogOpen(true);
  };

  const onSubmit = (data: InsertTravelBooking) => {
    bookingMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-page-title">حجز تذاكر السفر</h1>
          <p className="text-muted-foreground">ابحث عن رحلتك واحجز تذكرتك بسهولة</p>
        </div>

        {/* Search Form */}
        <Card className="mb-8" data-testid="card-search">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* From City */}
              <div className="space-y-2">
                <Label htmlFor="from-city">من</Label>
                <Select value={fromCity} onValueChange={setFromCity}>
                  <SelectTrigger id="from-city" data-testid="select-from-city">
                    <SelectValue placeholder="اختر المدينة" />
                  </SelectTrigger>
                  <SelectContent>
                    {sudaneseCities.map((city) => (
                      <SelectItem key={city} value={city}>{city}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* To City */}
              <div className="space-y-2">
                <Label htmlFor="to-city">إلى</Label>
                <Select value={toCity} onValueChange={setToCity}>
                  <SelectTrigger id="to-city" data-testid="select-to-city">
                    <SelectValue placeholder="اختر المدينة" />
                  </SelectTrigger>
                  <SelectContent>
                    {sudaneseCities.map((city) => (
                      <SelectItem key={city} value={city}>{city}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Date */}
              <div className="space-y-2">
                <Label>تاريخ السفر</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-right"
                      data-testid="button-select-date"
                    >
                      <CalendarIcon className="ml-2 h-4 w-4" />
                      {date ? format(date, "PPP", { locale: ar }) : "اختر التاريخ"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Passengers */}
              <div className="space-y-2">
                <Label htmlFor="passengers">عدد الركاب</Label>
                <Select value={passengers} onValueChange={setPassengers}>
                  <SelectTrigger id="passengers" data-testid="select-passengers">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                      <SelectItem key={num} value={num.toString()}>
                        {num} {num === 1 ? "راكب" : "ركاب"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Search Button */}
              <div className="space-y-2">
                <Label className="invisible">بحث</Label>
                <Button
                  className="w-full gap-2"
                  disabled={!fromCity || !toCity || !date}
                  data-testid="button-search"
                >
                  <Search className="h-4 w-4" />
                  <span>بحث</span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : tickets && tickets.length > 0 ? (
          <div className="space-y-4">
            {tickets.map((ticket) => (
              <Card key={ticket.id} className="hover-elevate transition-all" data-testid={`card-ticket-${ticket.id}`}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    {/* Agency & Route Info */}
                    <div className="flex-1 space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="bg-card w-16 h-16 rounded-lg flex items-center justify-center border border-card-border">
                          <Bus className="h-8 w-8 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg mb-1" data-testid={`text-agency-${ticket.id}`}>{ticket.agency.name}</h3>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Star className="h-3 w-3 fill-primary text-primary" />
                            <span>{ticket.agency.rating || "4.5"}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-primary" />
                          <span className="font-medium">{ticket.fromCity}</span>
                          <span className="text-muted-foreground">←</span>
                          <span className="font-medium">{ticket.toCity}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-primary" />
                          <span>المغادرة: {ticket.departureTime}</span>
                        </div>
                        {ticket.duration && (
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-primary" />
                            <span>المدة: {ticket.duration}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <Badge variant="secondary" className="gap-1">
                          <Bus className="h-3 w-3" />
                          {ticket.busType}
                        </Badge>
                        <Badge variant="outline" className="gap-1">
                          <Users className="h-3 w-3" />
                          {ticket.availableSeats} مقعد متاح
                        </Badge>
                      </div>
                    </div>

                    {/* Price & Booking */}
                    <div className="flex md:flex-col items-center md:items-end justify-between md:justify-center gap-4">
                      <div className="text-left md:text-right">
                        <div className="text-3xl font-bold text-primary" data-testid={`text-price-${ticket.id}`}>
                          {ticket.price} ج.س
                        </div>
                        <div className="text-sm text-muted-foreground">للراكب الواحد</div>
                      </div>
                      <Button
                        size="lg"
                        className="gap-2"
                        onClick={() => handleBooking(ticket)}
                        disabled={ticket.availableSeats < parseInt(passengers)}
                        data-testid={`button-book-${ticket.id}`}
                      >
                        <Bus className="h-4 w-4" />
                        <span>احجز الآن</span>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : fromCity && toCity ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Bus className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">لا توجد رحلات متاحة</h3>
              <p className="text-muted-foreground">جرب تغيير التاريخ أو المدن</p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">ابدأ البحث</h3>
              <p className="text-muted-foreground">اختر المدن والتاريخ للبحث عن رحلات متاحة</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Booking Dialog */}
      <Dialog open={bookingDialogOpen} onOpenChange={setBookingDialogOpen}>
        <DialogContent className="max-w-md" data-testid="dialog-booking">
          <DialogHeader>
            <DialogTitle>إكمال الحجز</DialogTitle>
            <DialogDescription>
              الرجاء إدخال بياناتك لإكمال الحجز
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="passengerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الاسم الكامل</FormLabel>
                    <FormControl>
                      <Input placeholder="أدخل اسمك الكامل" {...field} data-testid="input-passenger-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="passengerPhone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم الهاتف</FormLabel>
                    <FormControl>
                      <Input placeholder="0123456789" {...field} data-testid="input-passenger-phone" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="passengerEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>البريد الإلكتروني (اختياري)</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="example@email.com" {...field} data-testid="input-passenger-email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {selectedTicket && (
                <div className="bg-muted p-4 rounded-lg space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>المسار:</span>
                    <span className="font-medium">{selectedTicket.fromCity} ← {selectedTicket.toCity}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>عدد الركاب:</span>
                    <span className="font-medium">{form.getValues("numberOfPassengers")}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>سعر التذكرة:</span>
                    <span className="font-medium">{selectedTicket.price} ج.س</span>
                  </div>
                  <div className="border-t border-border pt-2 flex justify-between font-semibold">
                    <span>المجموع:</span>
                    <span className="text-primary">{form.getValues("totalPrice")} ج.س</span>
                  </div>
                </div>
              )}

              <DialogFooter className="gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setBookingDialogOpen(false)}
                  data-testid="button-cancel-booking"
                >
                  إلغاء
                </Button>
                <Button type="submit" disabled={bookingMutation.isPending} data-testid="button-confirm-booking">
                  {bookingMutation.isPending ? "جاري الحجز..." : "تأكيد الحجز"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
