import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { HelpCircle, Mail, Phone, Clock, Send, MessageSquare } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { insertSupportMessageSchema, type InsertSupportMessage } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Support() {
  const { toast } = useToast();

  const form = useForm<InsertSupportMessage>({
    resolver: zodResolver(insertSupportMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      category: "general",
      message: "",
    },
  });

  const supportMutation = useMutation({
    mutationFn: (data: InsertSupportMessage) => apiRequest("POST", "/api/support", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/support"] });
      toast({
        title: "تم إرسال رسالتك!",
        description: "سيتم الرد عليك في أقرب وقت ممكن.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "خطأ في الإرسال",
        description: "حدث خطأ أثناء إرسال الرسالة. الرجاء المحاولة مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertSupportMessage) => {
    supportMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
            <HelpCircle className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-page-title">الدعم الفني</h1>
          <p className="text-muted-foreground">نحن هنا لمساعدتك! تواصل معنا في أي وقت</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                أرسل رسالة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الاسم الكامل</FormLabel>
                        <FormControl>
                          <Input placeholder="أدخل اسمك الكامل" {...field} data-testid="input-name" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>البريد الإلكتروني</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="example@email.com" {...field} data-testid="input-email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>رقم الهاتف</FormLabel>
                        <FormControl>
                          <Input placeholder="0123456789" {...field} data-testid="input-phone" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>نوع الاستفسار</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-category">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="general">استفسار عام</SelectItem>
                            <SelectItem value="booking">حجز التذاكر</SelectItem>
                            <SelectItem value="cargo">الشحن</SelectItem>
                            <SelectItem value="technical">مشكلة تقنية</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الرسالة</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="اكتب رسالتك هنا..."
                            className="resize-none min-h-32"
                            {...field}
                            data-testid="input-message"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full gap-2"
                    disabled={supportMutation.isPending}
                    data-testid="button-submit-support"
                  >
                    <Send className="h-4 w-4" />
                    {supportMutation.isPending ? "جاري الإرسال..." : "إرسال الرسالة"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Contact Methods */}
            <Card>
              <CardHeader>
                <CardTitle>طرق التواصل</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Phone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">الهاتف</h4>
                    <p className="text-sm text-muted-foreground" dir="ltr">+249 123 456 789</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <SiWhatsapp className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">واتساب</h4>
                    <p className="text-sm text-muted-foreground" dir="ltr">+249 123 456 789</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">البريد الإلكتروني</h4>
                    <p className="text-sm text-muted-foreground">support@rehlaamna.sd</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">ساعات العمل</h4>
                    <p className="text-sm text-muted-foreground">السبت - الخميس: 8 صباحاً - 8 مساءً</p>
                    <p className="text-sm text-muted-foreground">الجمعة: مغلق</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* FAQ */}
            <Card>
              <CardHeader>
                <CardTitle>الأسئلة الشائعة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-1">كيف أحجز تذكرة؟</h4>
                  <p className="text-sm text-muted-foreground">
                    اذهب إلى صفحة "حجز التذاكر"، اختر المدينة المصدر والوجهة، ثم اختر الرحلة المناسبة واضغط على "احجز الآن".
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">كيف أتتبع شحنتي؟</h4>
                  <p className="text-sm text-muted-foreground">
                    سيتم إرسال رقم تتبع لك عبر الرسائل النصية بعد تأكيد الشحنة.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">ما هي وسائل الدفع المتاحة؟</h4>
                  <p className="text-sm text-muted-foreground">
                    يمكنك الدفع نقداً عند الاستلام أو التحويل البنكي.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
