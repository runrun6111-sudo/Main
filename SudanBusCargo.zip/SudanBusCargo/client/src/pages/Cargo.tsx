import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Package, MapPin, Weight, Ruler, DollarSign } from "lucide-react";
import { sudaneseCities, insertCargoShipmentSchema, type InsertCargoShipment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Cargo() {
  const { toast } = useToast();
  const [estimatedPrice, setEstimatedPrice] = useState<number | null>(null);

  const form = useForm<InsertCargoShipment>({
    resolver: zodResolver(insertCargoShipmentSchema),
    defaultValues: {
      senderName: "",
      senderPhone: "",
      senderAddress: "",
      receiverName: "",
      receiverPhone: "",
      receiverAddress: "",
      fromCity: "",
      toCity: "",
      packageType: "",
      weight: "",
      dimensions: "",
      estimatedPrice: "",
      status: "pending",
      notes: "",
    },
  });

  const shipmentMutation = useMutation({
    mutationFn: (data: InsertCargoShipment) => apiRequest("POST", "/api/cargo", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cargo"] });
      toast({
        title: "تم تسجيل طلب الشحن!",
        description: "سيتم التواصل معك قريباً لتأكيد الطلب وتحديد السعر النهائي.",
      });
      form.reset();
      setEstimatedPrice(null);
    },
    onError: () => {
      toast({
        title: "خطأ في التسجيل",
        description: "حدث خطأ أثناء تسجيل الطلب. الرجاء المحاولة مرة أخرى.",
        variant: "destructive",
      });
    },
  });

  const calculatePrice = () => {
    const weight = parseFloat(form.getValues("weight"));
    const fromCity = form.getValues("fromCity");
    const toCity = form.getValues("toCity");

    if (weight && fromCity && toCity) {
      // Simple pricing: 50 SDG base + 10 SDG per kg
      const basePrice = 50;
      const pricePerKg = 10;
      const calculated = basePrice + (weight * pricePerKg);
      setEstimatedPrice(calculated);
      form.setValue("estimatedPrice", calculated.toString());
    }
  };

  const onSubmit = (data: InsertCargoShipment) => {
    shipmentMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
            <Package className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-page-title">خدمة الشحن</h1>
          <p className="text-muted-foreground">
            اشحن بضائعك بأمان وسرعة عبر جميع ولايات السودان
          </p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Sender Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  بيانات المرسل
                </CardTitle>
              </CardHeader>
              <CardContent className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="senderName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>اسم المرسل</FormLabel>
                      <FormControl>
                        <Input placeholder="الاسم الكامل" {...field} data-testid="input-sender-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="senderPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رقم الهاتف</FormLabel>
                      <FormControl>
                        <Input placeholder="0123456789" {...field} data-testid="input-sender-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fromCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المدينة المصدر</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-from-city">
                            <SelectValue placeholder="اختر المدينة" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sudaneseCities.map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="senderAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>العنوان التفصيلي</FormLabel>
                      <FormControl>
                        <Input placeholder="الحي، الشارع" {...field} data-testid="input-sender-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Receiver Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  بيانات المستلم
                </CardTitle>
              </CardHeader>
              <CardContent className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="receiverName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>اسم المستلم</FormLabel>
                      <FormControl>
                        <Input placeholder="الاسم الكامل" {...field} data-testid="input-receiver-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="receiverPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رقم الهاتف</FormLabel>
                      <FormControl>
                        <Input placeholder="0123456789" {...field} data-testid="input-receiver-phone" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="toCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المدينة الوجهة</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-to-city">
                            <SelectValue placeholder="اختر المدينة" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sudaneseCities.map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="receiverAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>العنوان التفصيلي</FormLabel>
                      <FormControl>
                        <Input placeholder="الحي، الشارع" {...field} data-testid="input-receiver-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Package Details */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  تفاصيل البضاعة
                </CardTitle>
              </CardHeader>
              <CardContent className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="packageType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع البضاعة</FormLabel>
                      <FormControl>
                        <Input placeholder="مثال: أجهزة إلكترونية، ملابس، أثاث" {...field} data-testid="input-package-type" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الوزن (كجم)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Weight className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            type="number"
                            step="0.1"
                            placeholder="0.0"
                            className="pr-10"
                            {...field}
                            onChange={(e) => {
                              field.onChange(e);
                              calculatePrice();
                            }}
                            data-testid="input-weight"
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="dimensions"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الأبعاد (اختياري)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Ruler className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            placeholder="طول × عرض × ارتفاع (سم)"
                            className="pr-10"
                            {...field}
                            data-testid="input-dimensions"
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="md:col-span-2">
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>ملاحظات إضافية (اختياري)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="أي تفاصيل أو تعليمات خاصة بالشحنة"
                            className="resize-none"
                            rows={3}
                            {...field}
                            data-testid="input-notes"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Price Estimation */}
            {estimatedPrice !== null && (
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-5 w-5 text-primary" />
                      <span className="font-semibold">التكلفة التقديرية:</span>
                    </div>
                    <div className="text-3xl font-bold text-primary" data-testid="text-estimated-price">
                      {estimatedPrice.toFixed(2)} ج.س
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    * السعر النهائي قد يختلف حسب طبيعة البضاعة والمسافة
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Submit */}
            <div className="flex gap-4">
              <Button
                type="button"
                variant="outline"
                className="flex-1 gap-2"
                onClick={calculatePrice}
                disabled={!form.getValues("weight") || !form.getValues("fromCity") || !form.getValues("toCity")}
                data-testid="button-calculate-price"
              >
                <DollarSign className="h-4 w-4" />
                احسب التكلفة
              </Button>
              <Button
                type="submit"
                className="flex-1 gap-2"
                disabled={shipmentMutation.isPending}
                data-testid="button-submit-cargo"
              >
                <Package className="h-4 w-4" />
                {shipmentMutation.isPending ? "جاري الإرسال..." : "إرسال الطلب"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
