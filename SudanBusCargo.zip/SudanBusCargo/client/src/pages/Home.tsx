import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bus, Package, Search, Shield, Clock, Star } from "lucide-react";
import heroImage from "@assets/generated_images/sudanese_bus_station_hero_image.png";

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section
        className="relative h-[60vh] min-h-[500px] flex items-center justify-center"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/70" />

        {/* Content */}
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6" data-testid="text-hero-title">
            رحلتك تبدأ من هنا
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            احجز تذاكر السفر بالباص أو اشحن بضائعك بسهولة وأمان عبر جميع ولايات السودان
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              className="gap-2 h-12 px-8 text-base backdrop-blur-md bg-primary border border-primary-border"
              data-testid="button-hero-tickets"
              asChild
            >
              <Link href="/tickets">
                <Bus className="h-5 w-5" />
                <span>احجز تذكرة سفر</span>
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="gap-2 h-12 px-8 text-base backdrop-blur-md bg-white/10 border-white/30 text-white hover:bg-white/20"
              data-testid="button-hero-cargo"
              asChild
            >
              <Link href="/cargo">
                <Package className="h-5 w-5" />
                <span>اشحن بضاعة</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12" data-testid="text-services-title">خدماتنا</h2>
          
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {/* Ticket Booking Card */}
            <Card className="hover-elevate transition-all duration-200" data-testid="card-service-tickets">
              <CardContent className="p-8">
                <div className="bg-primary/10 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                  <Bus className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold mb-4">حجز تذاكر السفر</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  احجز تذكرتك من بين مجموعة واسعة من الوكالات الموثوقة. أسعار تنافسية ومواعيد مرنة لتناسب احتياجاتك.
                </p>
                <Button className="w-full gap-2" data-testid="button-service-tickets" asChild>
                  <Link href="/tickets">
                    <Search className="h-4 w-4" />
                    <span>ابحث عن تذكرة</span>
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Cargo Shipping Card */}
            <Card className="hover-elevate transition-all duration-200" data-testid="card-service-cargo">
              <CardContent className="p-8">
                <div className="bg-primary/10 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                  <Package className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold mb-4">شحن البضائع</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  خدمة شحن آمنة وموثوقة لبضائعك عبر جميع ولايات السودان. تتبع شحنتك واحصل على أفضل الأسعار.
                </p>
                <Button className="w-full gap-2" data-testid="button-service-cargo" asChild>
                  <Link href="/cargo">
                    <Package className="h-4 w-4" />
                    <span>اطلب شحنة</span>
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-card">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">لماذا نحن؟</h2>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">آمن وموثوق</h3>
                <p className="text-muted-foreground text-sm">نتعامل مع أفضل الوكالات المرخصة</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">وكالات متعددة</h3>
                <p className="text-muted-foreground text-sm">قارن الأسعار واختر الأفضل</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">حجز سريع</h3>
                <p className="text-muted-foreground text-sm">احجز تذكرتك في دقائق معدودة</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="bg-primary/10 w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bus className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">تغطية شاملة</h3>
                <p className="text-muted-foreground text-sm">جميع ولايات السودان</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">كيف يعمل؟</h2>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h3 className="font-semibold text-lg mb-2">ابحث عن رحلتك</h3>
              <p className="text-muted-foreground text-sm">
                اختر المدينة المصدر والوجهة وتاريخ السفر
              </p>
            </div>

            <div className="text-center">
              <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h3 className="font-semibold text-lg mb-2">اختر التذكرة</h3>
              <p className="text-muted-foreground text-sm">
                قارن الأسعار والمواعيد واختر الأنسب لك
              </p>
            </div>

            <div className="text-center">
              <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h3 className="font-semibold text-lg mb-2">أكمل الحجز</h3>
              <p className="text-muted-foreground text-sm">
                أدخل بياناتك واحصل على تأكيد فوري
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
