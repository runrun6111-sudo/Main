import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Agencies (الوكالات)
export const agencies = pgTable("agencies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  logo: text("logo"), // URL to agency logo
  rating: decimal("rating", { precision: 2, scale: 1 }).default("0"),
  phone: text("phone"),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAgencySchema = createInsertSchema(agencies).omit({
  id: true,
  createdAt: true,
});

export type InsertAgency = z.infer<typeof insertAgencySchema>;
export type Agency = typeof agencies.$inferSelect;

// Tickets (التذاكر المتاحة)
export const tickets = pgTable("tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  agencyId: varchar("agency_id").notNull().references(() => agencies.id),
  fromCity: text("from_city").notNull(),
  toCity: text("to_city").notNull(),
  departureTime: text("departure_time").notNull(), // e.g., "08:00"
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  availableSeats: integer("available_seats").notNull().default(50),
  busType: text("bus_type").notNull(), // "VIP" or "عادي"
  duration: text("duration"), // e.g., "3 ساعات"
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  createdAt: true,
});

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;

// Travel Bookings (حجوزات السفر)
export const travelBookings = pgTable("travel_bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ticketId: varchar("ticket_id").notNull().references(() => tickets.id),
  passengerName: text("passenger_name").notNull(),
  passengerPhone: text("passenger_phone").notNull(),
  passengerEmail: text("passenger_email"),
  numberOfPassengers: integer("number_of_passengers").notNull().default(1),
  travelDate: text("travel_date").notNull(), // YYYY-MM-DD format
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // "pending", "confirmed", "cancelled"
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTravelBookingSchema = createInsertSchema(travelBookings).omit({
  id: true,
  createdAt: true,
}).extend({
  passengerName: z.string().min(2, "الاسم يجب أن يكون حرفين على الأقل"),
  passengerPhone: z.string().min(10, "رقم الهاتف غير صحيح"),
  passengerEmail: z.string().email("البريد الإلكتروني غير صحيح").optional(),
  numberOfPassengers: z.number().min(1, "يجب اختيار راكب واحد على الأقل"),
  travelDate: z.string().min(1, "يجب اختيار تاريخ السفر"),
});

export type InsertTravelBooking = z.infer<typeof insertTravelBookingSchema>;
export type TravelBooking = typeof travelBookings.$inferSelect;

// Cargo/Shipment (طلبات الشحن)
export const cargoShipments = pgTable("cargo_shipments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderName: text("sender_name").notNull(),
  senderPhone: text("sender_phone").notNull(),
  senderAddress: text("sender_address").notNull(),
  receiverName: text("receiver_name").notNull(),
  receiverPhone: text("receiver_phone").notNull(),
  receiverAddress: text("receiver_address").notNull(),
  fromCity: text("from_city").notNull(),
  toCity: text("to_city").notNull(),
  packageType: text("package_type").notNull(), // نوع البضاعة
  weight: decimal("weight", { precision: 10, scale: 2 }).notNull(), // بالكيلوجرام
  dimensions: text("dimensions"), // الأبعاد (طول×عرض×ارتفاع)
  estimatedPrice: decimal("estimated_price", { precision: 10, scale: 2 }),
  status: text("status").notNull().default("pending"), // "pending", "in_transit", "delivered"
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCargoShipmentSchema = createInsertSchema(cargoShipments).omit({
  id: true,
  createdAt: true,
}).extend({
  senderName: z.string().min(2, "الاسم يجب أن يكون حرفين على الأقل"),
  senderPhone: z.string().min(10, "رقم الهاتف غير صحيح"),
  receiverName: z.string().min(2, "الاسم يجب أن يكون حرفين على الأقل"),
  receiverPhone: z.string().min(10, "رقم الهاتف غير صحيح"),
  packageType: z.string().min(2, "يجب تحديد نوع البضاعة"),
  weight: z.string().transform((val) => val.toString()),
});

export type InsertCargoShipment = z.infer<typeof insertCargoShipmentSchema>;
export type CargoShipment = typeof cargoShipments.$inferSelect;

// Support Messages (رسائل الدعم الفني)
export const supportMessages = pgTable("support_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  category: text("category").notNull(), // "general", "booking", "cargo", "technical"
  message: text("message").notNull(),
  status: text("status").notNull().default("new"), // "new", "in_progress", "resolved"
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSupportMessageSchema = createInsertSchema(supportMessages).omit({
  id: true,
  createdAt: true,
  status: true,
}).extend({
  name: z.string().min(2, "الاسم يجب أن يكون حرفين على الأقل"),
  email: z.string().email("البريد الإلكتروني غير صحيح"),
  phone: z.string().min(10, "رقم الهاتف غير صحيح"),
  message: z.string().min(10, "الرسالة يجب أن تكون 10 أحرف على الأقل"),
});

export type InsertSupportMessage = z.infer<typeof insertSupportMessageSchema>;
export type SupportMessage = typeof supportMessages.$inferSelect;

// Sudanese Cities for dropdowns
export const sudaneseCities = [
  "الخرطوم",
  "أم درمان",
  "بحري",
  "بورتسودان",
  "كسلا",
  "القضارف",
  "الأبيض",
  "نيالا",
  "الفاشر",
  "الجنينة",
  "واد مدني",
  "عطبرة",
  "الدمازين",
  "سنار",
  "كوستي",
  "دنقلا",
  "كريمة"
] as const;

export type SudaneseCity = typeof sudaneseCities[number];
