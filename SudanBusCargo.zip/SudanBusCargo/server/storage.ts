import {
  type Agency,
  type InsertAgency,
  type Ticket,
  type InsertTicket,
  type TravelBooking,
  type InsertTravelBooking,
  type CargoShipment,
  type InsertCargoShipment,
  type SupportMessage,
  type InsertSupportMessage,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Agencies
  getAgencies(): Promise<Agency[]>;
  getAgency(id: string): Promise<Agency | undefined>;
  createAgency(agency: InsertAgency): Promise<Agency>;
  
  // Tickets
  getTickets(fromCity?: string, toCity?: string): Promise<Ticket[]>;
  getTicket(id: string): Promise<Ticket | undefined>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  deleteTicket(id: string): Promise<boolean>;
  
  // Travel Bookings
  getBookings(): Promise<TravelBooking[]>;
  getBooking(id: string): Promise<TravelBooking | undefined>;
  createBooking(booking: InsertTravelBooking): Promise<TravelBooking>;
  
  // Cargo Shipments
  getCargoShipments(): Promise<CargoShipment[]>;
  getCargoShipment(id: string): Promise<CargoShipment | undefined>;
  createCargoShipment(shipment: InsertCargoShipment): Promise<CargoShipment>;
  
  // Support Messages
  getSupportMessages(): Promise<SupportMessage[]>;
  getSupportMessage(id: string): Promise<SupportMessage | undefined>;
  createSupportMessage(message: InsertSupportMessage): Promise<SupportMessage>;
}

export class MemStorage implements IStorage {
  private agencies: Map<string, Agency>;
  private tickets: Map<string, Ticket>;
  private bookings: Map<string, TravelBooking>;
  private cargo: Map<string, CargoShipment>;
  private support: Map<string, SupportMessage>;

  constructor() {
    this.agencies = new Map();
    this.tickets = new Map();
    this.bookings = new Map();
    this.cargo = new Map();
    this.support = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample agencies
    const agency1: Agency = {
      id: randomUUID(),
      name: "وكالة السلام للنقل",
      logo: "",
      rating: "4.8",
      phone: "+249 123 456 789",
      email: "info@alsalam.sd",
      createdAt: new Date(),
    };
    
    const agency2: Agency = {
      id: randomUUID(),
      name: "شركة الأمان للمواصلات",
      logo: "",
      rating: "4.6",
      phone: "+249 987 654 321",
      email: "contact@alaman.sd",
      createdAt: new Date(),
    };
    
    const agency3: Agency = {
      id: randomUUID(),
      name: "الخرطوم للنقل السريع",
      logo: "",
      rating: "4.7",
      phone: "+249 555 123 456",
      email: "support@khartoum-express.sd",
      createdAt: new Date(),
    };

    this.agencies.set(agency1.id, agency1);
    this.agencies.set(agency2.id, agency2);
    this.agencies.set(agency3.id, agency3);

    // Create sample tickets
    const sampleTickets: Omit<Ticket, "id" | "createdAt">[] = [
      {
        agencyId: agency1.id,
        fromCity: "الخرطوم",
        toCity: "بورتسودان",
        departureTime: "08:00",
        price: "350.00",
        availableSeats: 45,
        busType: "VIP",
        duration: "8 ساعات",
      },
      {
        agencyId: agency1.id,
        fromCity: "الخرطوم",
        toCity: "كسلا",
        departureTime: "09:30",
        price: "250.00",
        availableSeats: 38,
        busType: "عادي",
        duration: "6 ساعات",
      },
      {
        agencyId: agency2.id,
        fromCity: "الخرطوم",
        toCity: "نيالا",
        departureTime: "07:00",
        price: "450.00",
        availableSeats: 42,
        busType: "VIP",
        duration: "12 ساعة",
      },
      {
        agencyId: agency2.id,
        fromCity: "بورتسودان",
        toCity: "الخرطوم",
        departureTime: "19:00",
        price: "350.00",
        availableSeats: 50,
        busType: "عادي",
        duration: "8 ساعات",
      },
      {
        agencyId: agency3.id,
        fromCity: "الخرطوم",
        toCity: "واد مدني",
        departureTime: "10:00",
        price: "80.00",
        availableSeats: 30,
        busType: "عادي",
        duration: "2 ساعة",
      },
      {
        agencyId: agency3.id,
        fromCity: "الخرطوم",
        toCity: "القضارف",
        departureTime: "14:00",
        price: "200.00",
        availableSeats: 35,
        busType: "VIP",
        duration: "5 ساعات",
      },
    ];

    sampleTickets.forEach((ticketData) => {
      const ticket: Ticket = {
        ...ticketData,
        id: randomUUID(),
        createdAt: new Date(),
      };
      this.tickets.set(ticket.id, ticket);
    });
  }

  // Agencies
  async getAgencies(): Promise<Agency[]> {
    return Array.from(this.agencies.values());
  }

  async getAgency(id: string): Promise<Agency | undefined> {
    return this.agencies.get(id);
  }

  async createAgency(insertAgency: InsertAgency): Promise<Agency> {
    const agency: Agency = {
      ...insertAgency,
      id: randomUUID(),
      createdAt: new Date(),
    };
    this.agencies.set(agency.id, agency);
    return agency;
  }

  // Tickets
  async getTickets(fromCity?: string, toCity?: string): Promise<Ticket[]> {
    let tickets = Array.from(this.tickets.values());
    
    if (fromCity) {
      tickets = tickets.filter((t) => t.fromCity === fromCity);
    }
    
    if (toCity) {
      tickets = tickets.filter((t) => t.toCity === toCity);
    }
    
    return tickets;
  }

  async getTicket(id: string): Promise<Ticket | undefined> {
    return this.tickets.get(id);
  }

  async createTicket(insertTicket: InsertTicket): Promise<Ticket> {
    const ticket: Ticket = {
      ...insertTicket,
      id: randomUUID(),
      createdAt: new Date(),
    };
    this.tickets.set(ticket.id, ticket);
    return ticket;
  }

  async deleteTicket(id: string): Promise<boolean> {
    return this.tickets.delete(id);
  }

  // Travel Bookings
  async getBookings(): Promise<TravelBooking[]> {
    return Array.from(this.bookings.values());
  }

  async getBooking(id: string): Promise<TravelBooking | undefined> {
    return this.bookings.get(id);
  }

  async createBooking(insertBooking: InsertTravelBooking): Promise<TravelBooking> {
    const booking: TravelBooking = {
      ...insertBooking,
      id: randomUUID(),
      createdAt: new Date(),
    };
    this.bookings.set(booking.id, booking);
    
    // Decrease available seats
    const ticket = this.tickets.get(booking.ticketId);
    if (ticket) {
      ticket.availableSeats = Math.max(0, ticket.availableSeats - booking.numberOfPassengers);
      this.tickets.set(ticket.id, ticket);
    }
    
    return booking;
  }

  // Cargo Shipments
  async getCargoShipments(): Promise<CargoShipment[]> {
    return Array.from(this.cargo.values());
  }

  async getCargoShipment(id: string): Promise<CargoShipment | undefined> {
    return this.cargo.get(id);
  }

  async createCargoShipment(insertShipment: InsertCargoShipment): Promise<CargoShipment> {
    const shipment: CargoShipment = {
      ...insertShipment,
      id: randomUUID(),
      createdAt: new Date(),
    };
    this.cargo.set(shipment.id, shipment);
    return shipment;
  }

  // Support Messages
  async getSupportMessages(): Promise<SupportMessage[]> {
    return Array.from(this.support.values());
  }

  async getSupportMessage(id: string): Promise<SupportMessage | undefined> {
    return this.support.get(id);
  }

  async createSupportMessage(insertMessage: InsertSupportMessage): Promise<SupportMessage> {
    const message: SupportMessage = {
      ...insertMessage,
      id: randomUUID(),
      status: "new",
      createdAt: new Date(),
    };
    this.support.set(message.id, message);
    return message;
  }
}

export const storage = new MemStorage();
