import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertAgencySchema,
  insertTicketSchema,
  insertTravelBookingSchema,
  insertCargoShipmentSchema,
  insertSupportMessageSchema,
} from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // ==================== Agencies ====================
  
  // Get all agencies
  app.get("/api/agencies", async (req, res) => {
    try {
      const agencies = await storage.getAgencies();
      res.json(agencies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agencies" });
    }
  });

  // Get single agency
  app.get("/api/agencies/:id", async (req, res) => {
    try {
      const agency = await storage.getAgency(req.params.id);
      if (!agency) {
        return res.status(404).json({ error: "Agency not found" });
      }
      res.json(agency);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agency" });
    }
  });

  // Create agency
  app.post("/api/agencies", async (req, res) => {
    try {
      const validatedData = insertAgencySchema.parse(req.body);
      const agency = await storage.createAgency(validatedData);
      res.status(201).json(agency);
    } catch (error) {
      res.status(400).json({ error: "Invalid agency data" });
    }
  });

  // ==================== Tickets ====================
  
  // Get all tickets (with optional filtering)
  app.get("/api/tickets/all", async (req, res) => {
    try {
      const tickets = await storage.getTickets();
      const agencies = await storage.getAgencies();
      
      // Join tickets with their agencies
      const ticketsWithAgencies = tickets.map((ticket) => ({
        ...ticket,
        agency: agencies.find((a) => a.id === ticket.agencyId),
      }));
      
      res.json(ticketsWithAgencies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tickets" });
    }
  });

  // Search tickets (with city filtering)
  app.get("/api/tickets", async (req, res) => {
    try {
      const { fromCity, toCity } = req.query;
      const tickets = await storage.getTickets(
        fromCity as string,
        toCity as string
      );
      const agencies = await storage.getAgencies();
      
      // Join tickets with their agencies
      const ticketsWithAgencies = tickets.map((ticket) => ({
        ...ticket,
        agency: agencies.find((a) => a.id === ticket.agencyId),
      }));
      
      res.json(ticketsWithAgencies);
    } catch (error) {
      res.status(500).json({ error: "Failed to search tickets" });
    }
  });

  // Get single ticket
  app.get("/api/tickets/:id", async (req, res) => {
    try {
      const ticket = await storage.getTicket(req.params.id);
      if (!ticket) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      
      const agency = await storage.getAgency(ticket.agencyId);
      res.json({ ...ticket, agency });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch ticket" });
    }
  });

  // Create ticket
  app.post("/api/tickets", async (req, res) => {
    try {
      const validatedData = insertTicketSchema.parse(req.body);
      const ticket = await storage.createTicket(validatedData);
      res.status(201).json(ticket);
    } catch (error) {
      res.status(400).json({ error: "Invalid ticket data" });
    }
  });

  // Delete ticket
  app.delete("/api/tickets/:id", async (req, res) => {
    try {
      const success = await storage.deleteTicket(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      res.json({ message: "Ticket deleted successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete ticket" });
    }
  });

  // ==================== Travel Bookings ====================
  
  // Get all bookings
  app.get("/api/bookings", async (req, res) => {
    try {
      const bookings = await storage.getBookings();
      const tickets = await storage.getTickets();
      const agencies = await storage.getAgencies();
      
      // Join bookings with their tickets and agencies
      const bookingsWithDetails = bookings.map((booking) => {
        const ticket = tickets.find((t) => t.id === booking.ticketId);
        const agency = ticket ? agencies.find((a) => a.id === ticket.agencyId) : undefined;
        
        return {
          ...booking,
          ticket: ticket ? { ...ticket, agency } : undefined,
        };
      });
      
      res.json(bookingsWithDetails);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bookings" });
    }
  });

  // Get single booking
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const booking = await storage.getBooking(req.params.id);
      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }
      
      const ticket = await storage.getTicket(booking.ticketId);
      const agency = ticket ? await storage.getAgency(ticket.agencyId) : undefined;
      
      res.json({
        ...booking,
        ticket: ticket ? { ...ticket, agency } : undefined,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch booking" });
    }
  });

  // Create booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertTravelBookingSchema.parse(req.body);
      
      // Check if ticket exists and has available seats
      const ticket = await storage.getTicket(validatedData.ticketId);
      if (!ticket) {
        return res.status(404).json({ error: "Ticket not found" });
      }
      
      if (ticket.availableSeats < validatedData.numberOfPassengers) {
        return res.status(400).json({ error: "Not enough available seats" });
      }
      
      const booking = await storage.createBooking(validatedData);
      res.status(201).json(booking);
    } catch (error) {
      res.status(400).json({ error: "Invalid booking data" });
    }
  });

  // ==================== Cargo Shipments ====================
  
  // Get all cargo shipments
  app.get("/api/cargo", async (req, res) => {
    try {
      const shipments = await storage.getCargoShipments();
      res.json(shipments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cargo shipments" });
    }
  });

  // Get single cargo shipment
  app.get("/api/cargo/:id", async (req, res) => {
    try {
      const shipment = await storage.getCargoShipment(req.params.id);
      if (!shipment) {
        return res.status(404).json({ error: "Shipment not found" });
      }
      res.json(shipment);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch shipment" });
    }
  });

  // Create cargo shipment
  app.post("/api/cargo", async (req, res) => {
    try {
      const validatedData = insertCargoShipmentSchema.parse(req.body);
      const shipment = await storage.createCargoShipment(validatedData);
      res.status(201).json(shipment);
    } catch (error) {
      res.status(400).json({ error: "Invalid cargo shipment data" });
    }
  });

  // ==================== Support Messages ====================
  
  // Get all support messages
  app.get("/api/support", async (req, res) => {
    try {
      const messages = await storage.getSupportMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch support messages" });
    }
  });

  // Get single support message
  app.get("/api/support/:id", async (req, res) => {
    try {
      const message = await storage.getSupportMessage(req.params.id);
      if (!message) {
        return res.status(404).json({ error: "Message not found" });
      }
      res.json(message);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch message" });
    }
  });

  // Create support message
  app.post("/api/support", async (req, res) => {
    try {
      const validatedData = insertSupportMessageSchema.parse(req.body);
      const message = await storage.createSupportMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ error: "Invalid support message data" });
    }
  });

  return httpServer;
}
