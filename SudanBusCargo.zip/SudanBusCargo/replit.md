# Bus and Cargo Booking System - Sudan

## Overview

A bilingual (Arabic/English) bus ticket booking and cargo shipping platform designed specifically for Sudan. The application connects passengers and cargo senders with multiple transportation agencies across Sudanese states. Built with a full-stack TypeScript architecture, it features an RTL-first (right-to-left) interface optimized for Arabic users, with a mobile-first responsive design approach.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server with HMR (Hot Module Replacement)
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management with automatic caching and refetching

**UI Component System**
- Shadcn/ui component library (New York style variant) built on Radix UI primitives
- Tailwind CSS for utility-first styling with custom design tokens
- RTL-first layout system configured for Arabic reading patterns
- Cairo and Tajawal Google Fonts for Arabic typography optimization

**Design Approach**
- Hybrid design combining Booking.com's efficient flows with Material Design clarity
- Mobile-primary responsive design (most users book on phones)
- Trust-building through prominent pricing, agency logos, and availability status
- Custom CSS variables for theming with light mode support
- Elevation system using hover and active states for depth perception

**State Management**
- React Hook Form with Zod validation for form handling
- TanStack Query for API data fetching, caching, and synchronization
- Local component state for UI interactions

### Backend Architecture

**Server Framework**
- Express.js with TypeScript for RESTful API endpoints
- HTTP server created with Node's built-in `http` module
- Middleware stack: JSON parsing, URL encoding, raw body capture for webhook support

**API Design**
- RESTful endpoints organized by resource type (agencies, tickets, bookings, cargo, support)
- JSON request/response format
- Validation using Zod schemas shared between client and server
- Error handling with appropriate HTTP status codes

**Storage Layer**
- In-memory storage implementation (`MemStorage`) for development
- Interface-based design (`IStorage`) allowing easy database integration
- Drizzle ORM configured for PostgreSQL with schema definitions
- Database schema supports agencies, tickets, travel bookings, cargo shipments, and support messages

**Schema Design**
- Agencies: Company profiles with ratings, logos, and contact information
- Tickets: Available bus routes with pricing, schedules, and seat availability
- Travel Bookings: Passenger reservations linked to tickets
- Cargo Shipments: Freight shipping requests with sender/receiver details
- Support Messages: Customer service communications categorized by type

### Build & Deployment

**Development Mode**
- Vite dev server with middleware mode integration into Express
- Hot module replacement for rapid development
- Template reloading with cache busting

**Production Build**
- esbuild for server bundling with selective dependency bundling
- Vite for client-side bundling with optimized assets
- Static file serving from `dist/public` directory
- Single-file server output (`dist/index.cjs`)

### Route Structure

**Public Pages**
- `/` - Home page with hero section and service overview
- `/tickets` - Ticket search and booking interface
- `/cargo` - Cargo shipment request form
- `/support` - Customer support contact form

**Admin Pages**
- `/admin` - Dashboard for managing agencies, tickets, bookings, cargo, and support messages

## External Dependencies

**UI Component Libraries**
- @radix-ui/* - Accessible, unstyled UI primitives (accordion, dialog, dropdown, select, etc.)
- cmdk - Command palette component
- embla-carousel-react - Touch-friendly carousel
- lucide-react - Icon library
- react-icons - Additional icon sets (WhatsApp, etc.)

**Form Management**
- react-hook-form - Form state management
- @hookform/resolvers - Form validation resolvers
- zod - Schema validation
- drizzle-zod - Database schema to Zod conversion

**Data Fetching & State**
- @tanstack/react-query - Server state management
- wouter - Lightweight routing

**Styling**
- tailwindcss - Utility-first CSS framework
- tailwind-merge & clsx - Class name utilities
- class-variance-authority - Component variant handling
- autoprefixer - CSS vendor prefixing

**Database & ORM**
- @neondatabase/serverless - Neon PostgreSQL serverless driver
- drizzle-orm - TypeScript ORM
- drizzle-kit - Database migration toolkit
- connect-pg-simple - PostgreSQL session store (configured but not actively used)

**Utilities**
- date-fns - Date manipulation with Arabic locale support
- nanoid - Unique ID generation

**Build Tools**
- vite - Frontend build tool
- esbuild - Fast JavaScript bundler for server
- tsx - TypeScript execution
- typescript - Type checking

**Development Tools**
- @replit/vite-plugin-* - Replit-specific development enhancements