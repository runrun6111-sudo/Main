# تصميم موقع حجز تذاكر الباصات والشحن - السودان

## Design Approach
**Hybrid Approach**: Combining Booking.com's efficient booking flows with Material Design's clarity for Arabic RTL interfaces. Focus on trust-building through clean information hierarchy and seamless booking experiences.

## Core Design Principles
- **RTL-First Design**: All layouts mirrored for Arabic reading patterns
- **Trust & Clarity**: Prominent pricing, agency logos, and availability status
- **Booking Efficiency**: Minimal steps from search to confirmation
- **Mobile-Primary**: Most bookings happen on phones in Sudan

## Typography (Arabic-Optimized)
- **Primary**: 'Cairo' or 'Tajawal' (Google Fonts) - excellent Arabic rendering
- **Sizes**: Hero 3xl-4xl, Headers 2xl, Body lg, Captions sm
- **Weights**: Bold (700) for prices/CTAs, SemiBold (600) for headers, Regular (400) for body

## Layout System
**Spacing Units**: Tailwind 4, 6, 8, 12, 16 for consistent rhythm
- Section padding: py-12 md:py-20
- Card spacing: p-6 md:p-8
- Component gaps: gap-4 to gap-8
- Container: max-w-7xl with px-4 md:px-6

## Pages Structure

### 1. Home Page
**Hero Section** (50vh):
- Background: Vibrant image of Sudanese buses/roads with gradient overlay
- Centered search widget with blurred background (backdrop-blur-lg)
- Dual CTAs: "حجز تذكرة" and "شحن بضائع" with icons

**Services Grid** (2 columns):
- Large cards with icons: Ticket booking, Cargo shipping
- Hover elevation effect

**Trust Section**: 
- Stats row (3-4 columns): وكالات متعددة، مدن مخدومة، عملاء راضون
- Featured agencies logos grid (3-4 columns)

**How It Works**: 3-step process with numbered icons

### 2. Ticket Booking Page
**Search Bar** (sticky on scroll):
- From/To city dropdowns, Date picker, Passenger count
- Large "بحث" button

**Filters Sidebar** (desktop) / Drawer (mobile):
- Price range slider
- Departure time slots
- Agency checkboxes
- Bus type (VIP, عادي)

**Results List**:
- Card layout with: Agency logo, Route, Time, Duration, Price (large), Available seats badge
- "احجز الآن" button (prominent)
- Sort options: السعر، الوقت، التقييم

### 3. Cargo/Shipping Page
**Form Layout** (max-w-3xl centered):
- Two-column grid: Sender info | Receiver info
- Package details: Type, Weight, Dimensions
- Photo upload for package (optional visual proof)
- Price calculator showing real-time estimate
- Submit button: "احسب التكلفة وأرسل"

### 4. Admin Dashboard
**Sidebar Navigation** (fixed):
- Dashboard, Agencies, Tickets, Bookings, Cargo, Support, Settings

**Main Content Area**:
- Stats cards (4 columns): Today bookings, Revenue, Active tickets, Pending cargo
- Data tables with search/filter
- Action buttons: Add, Edit, Delete (icon + text)
- Modal forms for CRUD operations

### 5. Support Page
**Split Layout** (2 columns on desktop):
Left: Contact form (Name, Email, Phone, Category dropdown, Message)
Right: Support info (Hours, Phone, WhatsApp link, Email, FAQ links)

## Component Library

### Navigation
- Desktop: Horizontal bar with logo (right), links (center), Login/Register (left)
- Mobile: Hamburger menu icon with slide-in drawer
- Sticky on scroll with subtle shadow

### Cards
- Elevated with shadow-md, hover:shadow-lg transition
- Rounded corners: rounded-xl
- Padding: p-6
- Border on hover for ticket results

### Buttons
- Primary: Large (h-12), rounded-lg, font-semibold
- Secondary: Outlined variant
- On images: backdrop-blur-md bg-white/20 border border-white/30

### Forms
- Input height: h-12
- Labels: font-medium, mb-2
- Focus: ring-2 with brand color
- Validation: Border color changes + helper text

### Badges
- Pills for: Available seats, VIP, Express
- Small size with px-3 py-1

## Images
**Required Images**:
1. **Hero**: Wide-angle Sudanese highway/bus station (vibrant, high-quality)
2. **Service Cards**: Icons or small images for ticket/cargo services
3. **Agency Logos**: Placeholder squares for various bus companies
4. **How It Works**: Illustrative icons for 3-step process
5. **Support Page**: Optional customer service representative or contact illustration

**Hero Treatment**: Full-width, gradient overlay (from-black/60 to-black/30), backdrop-blur on search widget

## Animations
**Minimal & Purposeful**:
- Hover elevations on cards (shadow transition)
- Smooth page transitions
- Loading spinners for search results
- No scroll animations

## Mobile Optimization
- Stack all multi-column layouts to single column
- Bottom sheet for filters (instead of sidebar)
- Larger touch targets (min 44px)
- Simplified navigation with bottom tab bar option
- Collapsible sections in forms

## Accessibility (Arabic Context)
- High contrast text (AA compliance)
- Clear focus indicators
- Screen reader support with aria-labels in Arabic
- Keyboard navigation for all interactions
- Error messages in clear Arabic

**RTL Implementation**: Use Tailwind's `dir="rtl"` with proper logical properties (start/end instead of left/right)